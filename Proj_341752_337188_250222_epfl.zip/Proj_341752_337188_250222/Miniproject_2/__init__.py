import torch

# torch.set_grad_enabled(False)

torch.set_default_dtype(torch.float64)